############################################################
# CURRRENCY CONVERSION: Local costs -> International dollars (Intl$)
# using BOTH:
#   (1) CPI inflation adjustment (within-country over time), and
#   (2) PPP conversion (across-country price levels)
#
# INPUT:  An Excel (.xlsx) file with three variables:
#   - iso3     : 3-letter ISO code (e.g., "FRA", "THA", "ZAF")
#   - year     : year the cost was reported (e.g., 2015)
#   - cost_lcu : the cost in local currency units (LCU) for that year
#
# OUTPUT: An Excel file with added columns including:
#   - cost_ref_LCU     : cost adjusted to ref_year prices (still in LCU)
#   - cost_intl_ref    : cost in international dollars (Int-$) in ref_year
#
# Data source: World Bank via the WDI R package
# Indicators used:
#   - CPI: FP.CPI.TOTL  (Consumer Price Index, 2010=100)
#   - PPP: PA.NUS.PPP   (PPP conversion factor: LCU per international $)
############################################################

# -------------------------------------
# 1) Packages: install once, then load
# -------------------------------------
# Install these packages ONCE on your machine, then comment out install.packages().
#install.packages(c("WDI", "readxl", "writexl"))

library(WDI)     # download World Bank data
library(readxl)  # read Excel files
library(writexl) # write Excel files

# ---------------------------------------------------------
# 2) YOU EDIT THIS SECTION (file paths + reference year)
# ---------------------------------------------------------

# 2a) Your input file:
#     - Excel example: "currency_conversion_example.xlsx"
#     
input_file <- "currency_conversion_example.xlsx"

# 2b) The common comparison year for ALL studies (choose one and keep it fixed)
#     Example: 2023 means: "express all costs in 2023 prices and 2023 PPP"
ref_year <- 2023

# 2c) Output file name (will be created in your working directory)
output_file <- "costs_converted_to_international_dollars.xlsx"

# ---------------------------------------------------------
# 3) Read the input data (Excel)
# ---------------------------------------------------------
df <- read_excel(input_file)
df <- as.data.frame(df) 

# ----------------------------------------------------------------
# 4) Check the input columns (fail early if something is missing)
# ----------------------------------------------------------------
required_cols <- c("iso3", "year", "cost_lcu")

missing_cols <- setdiff(required_cols, names(df))
if (length(missing_cols) > 0) {
  stop(paste0(
    "Your file is missing these required columns: ",
    paste(missing_cols, collapse = ", "), "\n\n",
    "Your file must contain: iso3, year, cost_lcu"
  ))
}

# Make sure variables are in the right format
df$iso3 <- toupper(trimws(as.character(df$iso3)))  # clean ISO codes
df$year <- as.integer(df$year)
df$cost_lcu <- as.numeric(df$cost_lcu)

if (any(is.na(df$iso3) | nchar(df$iso3) != 3)) {
  stop("Some iso3 values are missing or not 3 letters. Example ISO3: 'FRA', 'THA', 'ZAF'.")
}
if (any(is.na(df$year))) {
  stop("Some year values are missing or not numeric.")
}
if (any(is.na(df$cost_lcu))) {
  stop("Some cost_lcu values are missing or not numeric.")
}

# ------------------------------------------------------------
# 5) Download the CPI and PPP data needed from the World Bank
# ------------------------------------------------------------
# We only download for the countries and years that appear in your dataset,
# plus the reference year

countries_needed <- unique(df$iso3)

min_year <- min(df$year, ref_year, na.rm = TRUE)
max_year <- max(df$year, ref_year, na.rm = TRUE)

# Download World Bank data:
# - CPI for all years we might need
# - PPP (LCU per Intl$) for all years, but we will use it specifically for ref_year
wb <- WDI(
  country   = countries_needed,
  indicator = c(CPI = "FP.CPI.TOTL", PPP = "PA.NUS.PPP"),
  start     = min_year,
  end       = max_year
)

if (nrow(wb) == 0) {
  stop("World Bank download returned no rows. Check your internet connection and ISO3 codes.")
}

# Ensure numeric format
wb$CPI <- as.numeric(wb$CPI)
wb$PPP <- as.numeric(wb$PPP)

# ---------------------------------------------------------
# 6) Merge CPI and PPP into your dataset
# ---------------------------------------------------------
# We need:
#   - CPI in the study year ("CPI_from")
#   - CPI in the reference year ("CPI_ref")
#   - PPP in the reference year ("PPP_ref")

# 6a) CPI in the study year
cpi_from <- wb[, c("iso3c", "year", "CPI")]
names(cpi_from) <- c("iso3", "year", "CPI_from")

df <- merge(df, cpi_from, by = c("iso3", "year"), all.x = TRUE)

# 6b) CPI and PPP in the reference year
wb_ref <- wb[wb$year == ref_year, c("iso3c", "country", "CPI", "PPP")]
names(wb_ref) <- c("iso3", "country", "CPI_ref", "PPP_ref")

df <- merge(df, wb_ref, by = "iso3", all.x = TRUE)

# ---------------------------------------------------------
# 7) Compute conversions: CPI adjustment + PPP conversion
# ---------------------------------------------------------

# 7a) Inflation adjustment (within the same country)
# CPI ratio moves the value from study-year prices to reference-year prices.
df$inflation_factor <- df$CPI_ref / df$CPI_from

# cost in reference-year local currency units (LCU)
df$cost_ref_LCU <- df$cost_lcu * df$inflation_factor

# 7b) PPP conversion: local currency -> international dollars
# PA.NUS.PPP = "LCU per international $"
# So: Intl$ = LCU / (LCU per Intl$)
df$cost_intl_ref <- df$cost_ref_LCU / df$PPP_ref

# ------------------------------
# 8) Flag missing data clearly 
# ------------------------------
# If CPI_from, CPI_ref, or PPP_ref is missing, the final Int-$ will be NA.
df$conversion_ok <- ifelse(
  is.na(df$CPI_from) | is.na(df$CPI_ref) | is.na(df$PPP_ref),
  FALSE, TRUE
)

# Add a simple text reason
df$conversion_note <- ""
df$conversion_note[is.na(df$CPI_from)] <- "Missing CPI for study year"
df$conversion_note[is.na(df$CPI_ref)]  <- "Missing CPI for reference year"
df$conversion_note[is.na(df$PPP_ref)]  <- "Missing PPP for reference year"

# Output unit label
df$unit_out <- paste0("international $ (", ref_year, ")")

# ---------------------------------------------------------
# 9) Write output to Excel
# ---------------------------------------------------------
write_xlsx(df, output_file)

cat("Done!\n")
cat("Wrote output file:", output_file, "\n")
cat("Rows converted successfully:", sum(df$conversion_ok, na.rm = TRUE), "out of", nrow(df), "\n")


