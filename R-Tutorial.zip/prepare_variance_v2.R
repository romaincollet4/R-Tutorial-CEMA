############################################################
#
# What this script does
# ---------------------
# This script reads an Excel template and prepares (or imputes) the
# variancea needed later for cost-effectiveness meta-analysis:
#
#   - Var(ΔC): variance of incremental costs
#   - Var(ΔE): variance of incremental effects (e.g., QALYs)
#   - Cov(ΔC, ΔE): set to 0 for all studies (tutorial assumption)
#
# It supports four reporting "scenarios":
#   1) reported_var : Var(ΔC) and Var(ΔE) are reported directly
#   2) diff_ci      : ΔC and ΔE are reported with 95% confidence intervals
#   3) ce_plane     : ΔC and ΔE points and their variances can be calculated from a CE-plane plot
#   4) borrow_var   : borrow variances from a methodologically similar study
#
# What you need to do (as a user)
# -------------------------------
# 1) Download the Excel template: "prepare_variance.xlsx"
# 2) Fill in the "studies" sheet (one row per study)
# 3) If you use Scenario = "ce_plane", also fill in "ce_plane_points"
# 4) Run this script. It will:
#      - create a clean output table, and
#      - save it as a NEW Excel file you can use in later steps.
#
# Required column in the "studies" sheet
# --------------------------------------
# Users MUST specify a column called "Scenario" with ONE of these values:
#   - "reported_var"
#   - "diff_ci"
#   - "ce_plane"
#   - "borrow_var"
#
############################################################


# ---- Packages ----
# If you do not have these installed yet, run:
# install.packages(c("readxl", "dplyr", "writexl"))

library(readxl)   # reads Excel files
library(dplyr)    
library(writexl)  # writes Excel files


############################################################
# Main function (NOTHING TO EDIT)
############################################################

compute_variance_inputs <- function(path_xlsx) {
  
  # --------------------------------------------------------
  # Step 0. Read the input data from Excel
  # --------------------------------------------------------
  dat <- read_excel(path_xlsx, sheet = "studies") %>% as.data.frame()
  
  # The "ce_plane_points" sheet is optional.
  ce_pts <- tryCatch(
    read_excel(path_xlsx, sheet = "ce_plane_points") %>% as.data.frame(),
    error = function(e) data.frame(
      StudyID = character(0),
      DeltaC  = numeric(0),
      DeltaE  = numeric(0)
    )
  )
  
  # --------------------------------------------------------
  # Step 0b. Make sure numeric columns are really numeric
  # --------------------------------------------------------
  # Converts European decimals like "0,06" to "0.06".
  num_cols <- c(
    "DeltaC_mean", "DeltaE_mean",
    "Var_DeltaC", "Var_DeltaE",
    "DeltaC_CI_lower", "DeltaC_CI_upper",
    "DeltaE_CI_lower", "DeltaE_CI_upper"
  )
  
  for (cc in intersect(num_cols, names(dat))) {
    dat[[cc]] <- as.numeric(gsub(",", ".", as.character(dat[[cc]])))
  }
  
  # -----------------------------------------------------------
  # Step 1. Tutorial assumption: 95% CI corresponds to z = 1.96
  # -----------------------------------------------------------
  z <- 1.96
  
  # ----------------------------------------------------------
  # Step 2. Scenario: "diff_ci"
  # Calculate Var(ΔC) and Var(ΔE) from 95% confidence intervals
  #
  # If a 95% CI is reported as:
  #   [Lower, Upper] = Mean ± 1.96 * SE
  # then:
  #   SE = (Upper - Lower) / (2 * 1.96)
  #   Var = SE^2
  # ----------------------------------------------------------
  dat <- dat %>%
    mutate(
      SE_DeltaC = ifelse(
        Scenario == "diff_ci",
        (DeltaC_CI_upper - DeltaC_CI_lower) / (2 * z),
        NA_real_
      ),
      Var_DeltaC = ifelse(
        Scenario == "diff_ci" & is.na(Var_DeltaC),
        SE_DeltaC^2,
        Var_DeltaC
      ),
      
      SE_DeltaE = ifelse(
        Scenario == "diff_ci",
        (DeltaE_CI_upper - DeltaE_CI_lower) / (2 * z),
        NA_real_
      ),
      Var_DeltaE = ifelse(
        Scenario == "diff_ci" & is.na(Var_DeltaE),
        SE_DeltaE^2,
        Var_DeltaE
      )
    )
  
  # -----------------------------------------------------------
  # Step 3. Scenario: "ce_plane"
  # Estimate means and variances from digitised CE-plane points
  # -----------------------------------------------------------
  ce_summ <- ce_pts %>%
    group_by(StudyID) %>%
    summarise(
      DeltaC_mean_from_plane = mean(DeltaC, na.rm = TRUE),
      DeltaE_mean_from_plane = mean(DeltaE, na.rm = TRUE),
      Var_DeltaC_from_plane  = var(DeltaC, na.rm = TRUE),
      Var_DeltaE_from_plane  = var(DeltaE, na.rm = TRUE),
      n_points = sum(complete.cases(DeltaC, DeltaE)),
      .groups = "drop"
    )
  
  dat <- dat %>%
    left_join(ce_summ, by = "StudyID") %>%
    mutate(
      DeltaC_mean = ifelse(
        Scenario == "ce_plane" & is.na(DeltaC_mean),
        DeltaC_mean_from_plane,
        DeltaC_mean
      ),
      DeltaE_mean = ifelse(
        Scenario == "ce_plane" & is.na(DeltaE_mean),
        DeltaE_mean_from_plane,
        DeltaE_mean
      ),
      Var_DeltaC = ifelse(
        Scenario == "ce_plane" & is.na(Var_DeltaC),
        Var_DeltaC_from_plane,
        Var_DeltaC
      ),
      Var_DeltaE = ifelse(
        Scenario == "ce_plane" & is.na(Var_DeltaE),
        Var_DeltaE_from_plane,
        Var_DeltaE
      )
    ) %>%
    select(
      -DeltaC_mean_from_plane, -DeltaE_mean_from_plane,
      -Var_DeltaC_from_plane, -Var_DeltaE_from_plane
    )
  
  # --------------------------------------------------------
  # Step 4. Scenario: "borrow_var"
  # Borrow variances from a similar referent study (scaled borrowing)
  #
  # # Var_imputed = Var_ref * (|Mean_imputed| / |Mean_ref|)^2
  # --------------------------------------------------------
  donor_lookup <- dat %>%
    select(
      StudyID,
      DeltaC_ref     = DeltaC_mean,
      DeltaE_ref     = DeltaE_mean,
      Var_DeltaC_ref = Var_DeltaC,
      Var_DeltaE_ref = Var_DeltaE
    )
  
  dat <- dat %>%
    left_join(donor_lookup, by = c("Borrow_from" = "StudyID")) %>%
    mutate(
      Var_DeltaC = ifelse(
        Scenario == "borrow_var" & is.na(Var_DeltaC) &
          !is.na(Var_DeltaC_ref) & !is.na(DeltaC_ref) & DeltaC_ref != 0 &
          !is.na(DeltaC_mean),
        Var_DeltaC_ref * (abs(DeltaC_mean) / abs(DeltaC_ref))^2,
        Var_DeltaC
      ),
      Var_DeltaE = ifelse(
        Scenario == "borrow_var" & is.na(Var_DeltaE) &
          !is.na(Var_DeltaE_ref) & !is.na(DeltaE_ref) & DeltaE_ref != 0 &
          !is.na(DeltaE_mean),
        Var_DeltaE_ref * (abs(DeltaE_mean) / abs(DeltaE_ref))^2,
        Var_DeltaE
      )
    ) %>%
    select(-DeltaC_ref, -DeltaE_ref, -Var_DeltaC_ref, -Var_DeltaE_ref)
  
  # --------------------------------------------------------
  # Step 5. Covariance assumption (tutorial choice)
  # --------------------------------------------------------
  dat$Cov_DeltaC_DeltaE <- 0
  
  # -----------------------------
  # Step 6. Quality flags
  # -----------------------------
  dat <- dat %>%
    mutate(
      flag_missing = case_when(
        Scenario == "reported_var" &
          (is.na(Var_DeltaC) | is.na(Var_DeltaE)) ~
          "Variances marked as reported but missing",
        
        Scenario == "diff_ci" &
          (is.na(DeltaC_CI_lower) | is.na(DeltaC_CI_upper) |
             is.na(DeltaE_CI_lower) | is.na(DeltaE_CI_upper)) ~
          "Missing 95% CI limits for ΔC and/or ΔE",
        
        Scenario == "ce_plane" &
          (is.na(Var_DeltaC) | is.na(Var_DeltaE) |
             is.na(DeltaC_mean) | is.na(DeltaE_mean)) ~
          "Missing CE-plane points or could not estimate mean/variance",
        
        Scenario == "borrow_var" &
          (is.na(Var_DeltaC) | is.na(Var_DeltaE)) ~
          "Borrowing failed (check Borrow_from ID and donor variances)",
        
        TRUE ~ ""
      )
    )
  
  return(dat)
}


##############################################################################
# Example run (YOU EDIT THIS PART)
##############################################################################

# 1) Put your Excel file in the same folder as this script
#    OR specify a full path, e.g. "C:/Users/.../prepare_variance.xlsx"
path_xlsx <- "prepare_variance.xlsx"

# 2) Choose an output file name (will be created in your working directory)
output_xlsx <- "prepared_variances_output.xlsx"

# 3) Run the function
variance_inputs <- compute_variance_inputs(path_xlsx)

# 4) Print the output in the console (optional)
print(variance_inputs)

# 5) Save the output as a NEW Excel file
write_xlsx(variance_inputs, output_xlsx)

cat("Saved output file:", output_xlsx, "\n")

# Tip:
# If some rows have a message in 'flag_missing', go back to the Excel file
# and check whether the required inputs for that Scenario are complete.
##############################################################################