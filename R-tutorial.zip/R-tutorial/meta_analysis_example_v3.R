############################################################
# META-ANALYSIS OF ΔC, ΔE, AND INB + CEAC
#
# Input:
#   An Excel file (e.g., "meta_analysis_example.xlsx") with one sheet called "studies"
#   containing at least these columns:
#     StudyID, DeltaC_mean, DeltaE_mean, Var_DeltaC, Var_DeltaE. (Cov_DeltaC_DeltaE 
#     can be missing; we set it to 0 in this tutorial)
#
# Output:
#   1) Meta-analysis results for ΔC and ΔE + forest/funnel plots
#   2) Repeated INB meta-analyses across willingness-to-pay thresholds (K)
#   3) A pooled CEAC plot: one-sided confidence-based measure for average INB > 0 across K
#
# Notes:
#   - Var_DeltaC and Var_DeltaE are assumed to be variances of the incremental
#     estimates (ΔC and ΔE). Therefore SE = sqrt(Var).
#   - For the CEAC probability we use the random-effects meta-analysis p-value
#     (Hartung–Knapp inference) and convert it to a one-sided confidence-based measure.
############################################################

# ---- Packages ----
# Install once if needed:
# install.packages(c("readxl", "dplyr", "meta", "ggplot2", "scales"))


library(readxl)
library(dplyr)
library(meta)
library(ggplot2)
library(scales)


# ---------------------------------------------------------
# 1) Read your data
# ---------------------------------------------------------
# Put your Excel file in the same folder as this script,
# or provide the full path.
path_xlsx <- "meta_analysis_example.xlsx"
dat <- read_excel(path_xlsx, sheet = "studies") %>% as.data.frame()

# ---------------------------------------------------------
# 2) Clean numeric columns (handles commas as decimals, e.g., "0,06")
# ---------------------------------------------------------
num_cols <- c("DeltaC_mean", "DeltaE_mean", "SE_DeltaC", "SE_DeltaE", "Var_DeltaC", "Var_DeltaE",
              "Cov_DeltaC_DeltaE", "n_exp", "n_con")

for (cc in intersect(num_cols, names(dat))) {
  dat[[cc]] <- as.numeric(gsub(",", ".", as.character(dat[[cc]])))
}

# If covariance is missing, set it to 0 (tutorial assumption)
if (!("Cov_DeltaC_DeltaE" %in% names(dat))) dat$Cov_DeltaC_DeltaE <- 0
dat$Cov_DeltaC_DeltaE[is.na(dat$Cov_DeltaC_DeltaE)] <- 0

# ---------------------------------------------------------
# 3) Convert variances into standard errors and vice versa
# ---------------------------------------------------------
# IMPORTANT:
# Var_DeltaC and Var_DeltaE are assumed to be variances of the incremental
# estimates (ΔC and ΔE), NOT individual-level variances.
# Therefore: SE = sqrt(Var)
# Use SEs if reported; otherwise derive from variances
dat <- dat %>%
  mutate(
    SE_DeltaC = ifelse(!is.na(SE_DeltaC) & SE_DeltaC > 0,
                       SE_DeltaC,
                       ifelse(!is.na(Var_DeltaC) & Var_DeltaC >= 0,
                              sqrt(Var_DeltaC),
                              NA_real_)),
    SE_DeltaE = ifelse(!is.na(SE_DeltaE) & SE_DeltaE > 0,
                       SE_DeltaE,
                       ifelse(!is.na(Var_DeltaE) & Var_DeltaE >= 0,
                              sqrt(Var_DeltaE),
                              NA_real_))
  )

#create variances from SEs when variances are missing (useful later for INB/CEAC)
dat <- dat %>%
  mutate(
    Var_DeltaC = ifelse(is.na(Var_DeltaC) & !is.na(SE_DeltaC), SE_DeltaC^2, Var_DeltaC),
    Var_DeltaE = ifelse(is.na(Var_DeltaE) & !is.na(SE_DeltaE), SE_DeltaE^2, Var_DeltaE)
  )

# ---------------------------------------------------------
# 4) Meta-analysis of ΔC (incremental costs)
# ---------------------------------------------------------
m_dc <- metagen(
  TE = DeltaC_mean,
  seTE = SE_DeltaC,
  studlab = StudyID,
  data = dat,
  sm = "MD",                 # mean difference (continuous outcome)
  common = FALSE,            # common effect = fixed effect; set to "TRUE" to show the results of the fixed-effect model
  random = TRUE,
  method.tau = "REML",
  method.random.ci = "HK",   # Hartung–Knapp CI; please note that other types of estimators are available (e.g., "classic" for normal Wald CI )
  title = "Meta-analysis of incremental costs (ΔC)"
)

print(m_dc)

# Forest plot (ΔC)
forest(m_dc,
       sortvar = TE,
       prediction = TRUE,
       print.tau2 = TRUE,
       leftcols = "studlab",
       leftlabs = "Study"
)

# Funnel plot (ΔC)
funnel(m_dc, studlab = TRUE)

# ---------------------------------------------------------
# 5) Meta-analysis of ΔE (incremental effects, e.g., QALYs)
# ---------------------------------------------------------
m_de <- metagen(
  TE = DeltaE_mean,
  seTE = SE_DeltaE,
  studlab = StudyID,
  data = dat,
  sm = "MD",
  common = FALSE,
  random = TRUE,
  method.tau = "REML",
  method.random.ci = "HK",
  title = "Meta-analysis of incremental effects (ΔE)"
)

print(m_de)

# Forest plot (ΔE)
forest(m_de,
       sortvar = TE,
       prediction = TRUE,
       print.tau2 = TRUE,
       leftcols = "studlab",
       leftlabs = "Study")

# Funnel plot (ΔE)
funnel(m_de, studlab = TRUE)

# ---------------------------------------------------------
# 6a) Repeated INB meta-analyses across WTP thresholds (K)
# ---------------------------------------------------------
# Define willingness-to-pay thresholds (in your chosen currency)
K_values <- seq(0, 100000, by = 5000)

# Create a results table to store pooled INB and CEAC probability
results_inb <- data.frame(
  K = K_values,
  pooled_INB = NA_real_,
  SE_pooled_INB = NA_real_,
  CI_lower = NA_real_,
  CI_upper = NA_real_,
  PI_lower = NA_real_,
  PI_upper = NA_real_,
  tau2 = NA_real_,
  I2 = NA_real_,
  prob_CE = NA_real_,
  prob_CE_lower = NA_real_,
  prob_CE_upper = NA_real_
)
# Loop over thresholds
for (i in seq_along(K_values)) {
  
  K <- K_values[i]
  
  # Study-level INB:
  # INB = K * ΔE − ΔC
  INB <- K * dat$DeltaE_mean - dat$DeltaC_mean
  
  # Study-level variance of INB:
  # Var(INB) = K^2 * Var(ΔE) + Var(ΔC) − 2K * Cov(ΔE, ΔC)
  Var_INB <- (K^2) * dat$Var_DeltaE + dat$Var_DeltaC - 2 * K * dat$Cov_DeltaC_DeltaE
  
  # Numerical safety: variance should not be negative
  Var_INB <- pmax(Var_INB, 0)
  SE_INB <- sqrt(Var_INB)
  
  # Random-effects meta-analysis of INB at this K
  m_inb <- metagen(
    TE = INB,
    seTE = SE_INB,
    studlab = dat$StudyID,
    sm = "MD",
    common = FALSE,
    random = TRUE,
    method.tau = "REML",
    method.random.ci = "HK",
    title = paste0("INB meta-analysis (K = ", K, ")")
  )
  
  # Store pooled results (random-effects)
  results_inb$pooled_INB[i]    <- m_inb$TE.random
  results_inb$SE_pooled_INB[i] <- m_inb$seTE.random
  results_inb$CI_lower[i]      <- m_inb$lower.random
  results_inb$CI_upper[i]      <- m_inb$upper.random
  results_inb$I2[i]            <- m_inb$I2
  results_inb$tau2[i]          <- m_inb$tau^2
  results_inb$PI_lower[i] <- m_inb$lower.predict
  results_inb$PI_upper[i] <- m_inb$upper.predict
  # -------------------------------------------------------
  # Probability cost-effective (CEAC point):
  # Use Hartung–Knapp random-effects inference.
  #
  # We take the two-sided p-value for H0: average pooled INB = 0
  # and convert it into a one-sided confidence-based measure for average pooled INB > 0.
  # -------------------------------------------------------
  p_two <- m_inb$pval.random
  
  prob_ce <- ifelse(
    m_inb$TE.random >= 0,
    1 - p_two / 2,  # if pooled INB is positive
    p_two / 2       # if pooled INB is negative
  )
  
  results_inb$prob_CE[i] <- prob_ce * 100
}

# ---------------------------------------------------------
# Pointwise uncertainty bands around the pooled CEAC
# ---------------------------------------------------------
set.seed(1234)

n_sim <- 10000

for (i in seq_len(nrow(results_inb))) {
  
  sim_pooled_INB <- rnorm(
    n = n_sim,
    mean = results_inb$pooled_INB[i],
    sd = results_inb$SE_pooled_INB[i]
  )
  
  sim_prob_CE <- pnorm(sim_pooled_INB / results_inb$SE_pooled_INB[i]) * 100
  
  results_inb$prob_CE_lower[i] <- quantile(sim_prob_CE, 0.025, na.rm = TRUE)
  results_inb$prob_CE_upper[i] <- quantile(sim_prob_CE, 0.975, na.rm = TRUE)
}

print(results_inb)

# -------------------------------------------------------------
# 6b) INB meta-analysis at a single user-specified K
# -------------------------------------------------------------
# Users can set:
#   - do_single_inb: TRUE/FALSE to turn this section on/off
#   - K_single: the willingness-to-pay threshold to use

do_single_inb <- TRUE
K_single <- 50000   # <-  ENTER K VALUE HERE

if (isTRUE(do_single_inb)) {
  
  # Study-level INB at user-specified K:
  # INB = K * ΔE − ΔC
  INB_single <- K_single * dat$DeltaE_mean - dat$DeltaC_mean
  
  # Variance of INB at user-specified K:
  # Var(INB) = K^2 * Var(ΔE) + Var(ΔC) − 2K * Cov(ΔE, ΔC)
  Var_INB_single <- (K_single^2) * dat$Var_DeltaE +
    dat$Var_DeltaC -
    2 * K_single * dat$Cov_DeltaC_DeltaE
  
  # Numerical safety: variance should not be negative
  Var_INB_single <- pmax(Var_INB_single, 0)
  SE_INB_single <- sqrt(Var_INB_single)
  
  # Random-effects meta-analysis of INB at this K
  m_inb_single <- metagen(
    TE = INB_single,
    seTE = SE_INB_single,
    studlab = dat$StudyID,
    sm = "MD",
    common = FALSE,
    random = TRUE,
    method.tau = "REML",
    method.random.ci = "HK",
    title = paste0("INB meta-analysis (K = ", K_single, ")")
  )
  
  print(m_inb_single)
  
  # Forest plot (INB at single K)
  forest(
    m_inb_single,
    sortvar = TE,
    prediction = TRUE,
    print.tau2 = TRUE,
    leftcols = "studlab",
    leftlabs = "Study",
    xlab = paste0("Incremental Net Benefit (K = ", K_single, ")")
  )
  
}

# ---------------------------------------------------------
# 7) Plot the pooled CEAC
# ---------------------------------------------------------
ggplot(results_inb, aes(x = K, y = prob_CE)) +
  geom_ribbon(
    aes(ymin = prob_CE_lower, ymax = prob_CE_upper),
    alpha = 0.2
  ) +
  geom_line(linewidth = 1) +
  scale_y_continuous(
    limits = c(0, 100),
    breaks = seq(0, 100, by = 10),
    labels = percent_format(scale = 1)
  ) +
  scale_x_continuous(
    breaks = seq(min(results_inb$K), max(results_inb$K), by = 10000),
    labels = comma_format()
  ) +
  labs(
    x = "Willingness-to-pay threshold (K)",
    y = "Confidence-based measure for average INB > 0"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black")
  )
